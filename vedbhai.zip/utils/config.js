const config = {
    passport: {
        secret: 'fsfssf',
        expiresIn: 10000
    },
    secret:'test',
}
module.exports.config=config; 

